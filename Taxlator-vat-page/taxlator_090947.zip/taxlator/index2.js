const slides = document.querySelectorAll(".slide");
let index = 0;

setInterval(() => {
  slides[index].classList.remove("active");
  index = (index + 2) % slides.length;
  slides[index].classList.add("active");
}, 4000);

